#pragma once

void SendToServer(stPacketHeader* Header, char* pPacket);